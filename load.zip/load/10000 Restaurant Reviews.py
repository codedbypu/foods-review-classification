import os
import shutil
import kagglehub
import pandas as pd

print("กำลังเริ่มขั้นตอนดาวน์โหลดข้อมูล...")

try:
    # 1. ดาวน์โหลดโครงสร้างโฟลเดอร์ของ Dataset จาก Kaggle ลงเครื่องคอมพิวเตอร์
    # ระบบจะเช็กสิทธิ์และเก็บไฟล์ทั้งหมดลงในโฟลเดอร์ Cache อัตโนมัติ
    path = kagglehub.dataset_download("joebeachcapital/restaurant-reviews")
    print(f"ดาวน์โหลดไฟล์ลงใน Cache เรียบร้อยแล้วที่: {path}")

    # 2. ค้นหาและระบุเป้าหมายของไฟล์รีวิวที่ต้องการแปลง (ชื่อไฟล์ restaurant_reviews.csv)
    target_file = os.path.join(path, "restaurant_reviews.csv")

    if os.path.exists(target_file):
        # 3. ใช้ pandas อ่านข้อมูลจากไฟล์ที่ดาวน์โหลดมา
        df = pd.read_csv(target_file)
        
        # 4. แสดงตัวอย่างเพื่อความแน่ใจ
        print("\n--- ตัวอย่างข้อมูลจาก Kaggle ---")
        print(df.head(3))
        print(f"จำนวนข้อมูลทั้งหมด: {len(df)} แถว")
        
        # 5. บันทึกผลลัพธ์เป็นไฟล์ CSV ในโฟลเดอร์โครงการปัจจุบัน
        output_filename = "kaggle_restaurant_reviews.csv"
        df.to_csv(output_filename, index=False, encoding="utf-8-sig")
        print(f"\nบันทึกไฟล์สำเร็จ! ชื่อไฟล์ของคุณคือ: '{output_filename}'")
    else:
        print("ไม่พบไฟล์ชื่อ 'restaurant_reviews.csv' ในชุดข้อมูลนี้ กรุณาตรวจสอบชื่อไฟล์อีกครั้ง")

except Exception as e:
    print(f"เกิดข้อผิดพลาดในการทำงาน: {e}")
