import pandas as pd

# 1. โหลดข้อมูลจาก Hugging Face (ลิงก์ตรงไปยังไฟล์ CSV)
print("กำลังดาวน์โหลดข้อมูล...")
url = "hf://datasets/wttw/restaurant_review/Review.csv"
df = pd.read_csv(url)

# 2. แสดงตัวอย่างข้อมูลและจำนวนแถวทั้งหมด
print("\n--- ตัวอย่างข้อมูลที่โหลดมาได้ ---")
print(df.head(3))
print(f"จำนวนข้อมูลทั้งหมด: {len(df)} แถว")

# 3. บันทึกข้อมูลเป็นไฟล์ CSV ลงเครื่องคอมพิวเตอร์
# (ใส่ encoding="utf-8-sig" เพื่อป้องกันปัญหาภาษาไทยเพี้ยนเมื่อเปิดใน Excel)
output_filename = "restaurant_review_all.csv"
df.to_csv(output_filename, index=False, encoding="utf-8-sig")

print(f"\nบันทึกไฟล์ '{output_filename}' เรียบร้อยแล้วในโฟลเดอร์ของคุณ!")
