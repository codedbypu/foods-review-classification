import pandas as pd

# 1. กำหนดโครงสร้าง Path ของ Dataset จาก Hugging Face
base_url = "hf://datasets/iamwarint/wongnai-restaurant-review/"
splits = {
    'train': 'data/train-00000-of-00001.parquet', 
    'test': 'data/test-00000-of-00001.parquet'
}

# 2. โหลดข้อมูลทั้งฝั่ง Train และ Test เข้ามาใน Python
print("กำลังดาวน์โหลดข้อมูล...")
df_train = pd.read_parquet(base_url + splits["train"])
df_test = pd.read_parquet(base_url + splits["test"])

# 3. แสดงตัวอย่างข้อมูลบนหน้าจอเพื่อความมั่นใจ
print("\n--- ตัวอย่างข้อมูล Train ---")
print(df_train.head(3))
print(f"จำนวนข้อมูล Train ทั้งหมด: {len(df_train)} แถว")

print("\n--- ตัวอย่างข้อมูล Test ---")
print(df_test.head(3))
print(f"จำนวนข้อมูล Test ทั้งหมด: {len(df_test)} แถว")

# 4. บันทึกข้อมูลแยกออกเป็น 2 ไฟล์ CSV
# (ใส่ encoding="utf-8-sig" เพื่อให้เปิดใน Excel แล้วภาษาไทยไม่เป็นต่างดาว)
df_train.to_csv("wongnai_train.csv", index=False, encoding="utf-8-sig")
df_test.to_csv("wongnai_test.csv", index=False, encoding="utf-8-sig")

print("\nบันทึกไฟล์ 'wongnai_train.csv' และ 'wongnai_test.csv' เรียบร้อยแล้ว!")
